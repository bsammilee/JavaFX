package javafxapplication1;
public class Entry {
    
public String name, notes;
public int quantity;

public Entry (){
    this.name = "";
    this.quantity = 0;
    this.notes = "";
}

public Entry (String name, int quantity, String notes){
    this.name = name;
    this.quantity = quantity;
    this.notes = notes;
}

public String getName() {
    return name;
}
public void setName(String name) {
    this.name = name;
}
public int getQuantity() {
    return quantity;
}
public void setQuantity(int quantity){
    this.quantity = quantity;
}
public String getNotes() {
    return notes;
}
public void setNotes(String notes) {
    this.notes = notes;
}

}